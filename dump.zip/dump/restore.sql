--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.1
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.oblubenost DROP CONSTRAINT oblubenost_inzeraty_id_fkey;
ALTER TABLE ONLY public.inzeraty DROP CONSTRAINT inzeraty_mesto_id_fkey;
ALTER TABLE ONLY public.inzeraty DROP CONSTRAINT inzeraty_autor_id_fkey;
ALTER TABLE ONLY public.cesty DROP CONSTRAINT cesty_mesta_to_fkey;
ALTER TABLE ONLY public.cesty DROP CONSTRAINT cesty_mesta_from_fkey;
ALTER TABLE ONLY public.autorstvo DROP CONSTRAINT autorstvo_inzeraty_id_fkey;
ALTER TABLE ONLY public.uzivatelia DROP CONSTRAINT uzivatelia_pk;
ALTER TABLE ONLY public.oblubenost DROP CONSTRAINT oblubenost_pk;
ALTER TABLE ONLY public.mesta DROP CONSTRAINT mesta_pk;
ALTER TABLE ONLY public.inzeraty DROP CONSTRAINT inzeraty_pk;
ALTER TABLE ONLY public.cesty DROP CONSTRAINT cesty_pk;
ALTER TABLE ONLY public.autorstvo DROP CONSTRAINT autorstvo_pk;
ALTER TABLE public.oblubenost ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inzeraty ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.autorstvo ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.uzivatelia;
DROP SEQUENCE public.oblubenost_id_seq;
DROP TABLE public.oblubenost;
DROP TABLE public.mesta;
DROP SEQUENCE public.inzeraty_id_seq;
DROP TABLE public.inzeraty;
DROP TABLE public.cesty;
DROP SEQUENCE public.autorstvo_id_seq;
DROP TABLE public.autorstvo;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: users; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE users IS 'users';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: autorstvo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE autorstvo (
    id integer NOT NULL,
    uzivatelia_id integer,
    inzeraty_id integer
);


ALTER TABLE autorstvo OWNER TO postgres;

--
-- Name: autorstvo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE autorstvo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE autorstvo_id_seq OWNER TO postgres;

--
-- Name: autorstvo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE autorstvo_id_seq OWNED BY autorstvo.id;


--
-- Name: cesty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cesty (
    id integer NOT NULL,
    mesta_from integer,
    mesta_to integer,
    vzdialenost integer
);


ALTER TABLE cesty OWNER TO postgres;

--
-- Name: inzeraty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inzeraty (
    id integer NOT NULL,
    cena integer,
    nazov character varying(50),
    typ character varying(20),
    info character varying(200),
    keywords character varying(50),
    autor_id integer,
    mesto_id integer
);


ALTER TABLE inzeraty OWNER TO postgres;

--
-- Name: inzeraty_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inzeraty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE inzeraty_id_seq OWNER TO postgres;

--
-- Name: inzeraty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inzeraty_id_seq OWNED BY inzeraty.id;


--
-- Name: mesta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mesta (
    id integer NOT NULL,
    nazov character varying(50)
);


ALTER TABLE mesta OWNER TO postgres;

--
-- Name: oblubenost; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE oblubenost (
    id integer NOT NULL,
    uzivatelia_id integer,
    inzeraty_id integer
);


ALTER TABLE oblubenost OWNER TO postgres;

--
-- Name: oblubenost_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE oblubenost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE oblubenost_id_seq OWNER TO postgres;

--
-- Name: oblubenost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE oblubenost_id_seq OWNED BY oblubenost.id;


--
-- Name: uzivatelia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE uzivatelia (
    id integer NOT NULL,
    username character varying(50),
    name character varying(50),
    surname character varying(50),
    password character varying(20),
    email character varying(50),
    phone character varying(50)
);


ALTER TABLE uzivatelia OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY autorstvo ALTER COLUMN id SET DEFAULT nextval('autorstvo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inzeraty ALTER COLUMN id SET DEFAULT nextval('inzeraty_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY oblubenost ALTER COLUMN id SET DEFAULT nextval('oblubenost_id_seq'::regclass);


--
-- Data for Name: autorstvo; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2182.dat

--
-- Name: autorstvo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('autorstvo_id_seq', 11, true);


--
-- Data for Name: cesty; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2181.dat

--
-- Data for Name: inzeraty; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2179.dat

--
-- Name: inzeraty_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inzeraty_id_seq', 11, true);


--
-- Data for Name: mesta; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2180.dat

--
-- Data for Name: oblubenost; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2183.dat

--
-- Name: oblubenost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('oblubenost_id_seq', 15, true);


--
-- Data for Name: uzivatelia; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2178.dat

--
-- Name: autorstvo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY autorstvo
    ADD CONSTRAINT autorstvo_pk PRIMARY KEY (id);


--
-- Name: cesty_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cesty
    ADD CONSTRAINT cesty_pk PRIMARY KEY (id);


--
-- Name: inzeraty_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inzeraty
    ADD CONSTRAINT inzeraty_pk PRIMARY KEY (id);


--
-- Name: mesta_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mesta
    ADD CONSTRAINT mesta_pk PRIMARY KEY (id);


--
-- Name: oblubenost_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY oblubenost
    ADD CONSTRAINT oblubenost_pk PRIMARY KEY (id);


--
-- Name: uzivatelia_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY uzivatelia
    ADD CONSTRAINT uzivatelia_pk PRIMARY KEY (id);


--
-- Name: autorstvo_inzeraty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY autorstvo
    ADD CONSTRAINT autorstvo_inzeraty_id_fkey FOREIGN KEY (inzeraty_id) REFERENCES inzeraty(id);


--
-- Name: cesty_mesta_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cesty
    ADD CONSTRAINT cesty_mesta_from_fkey FOREIGN KEY (mesta_from) REFERENCES mesta(id);


--
-- Name: cesty_mesta_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cesty
    ADD CONSTRAINT cesty_mesta_to_fkey FOREIGN KEY (mesta_to) REFERENCES mesta(id);


--
-- Name: inzeraty_autor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inzeraty
    ADD CONSTRAINT inzeraty_autor_id_fkey FOREIGN KEY (autor_id) REFERENCES uzivatelia(id);


--
-- Name: inzeraty_mesto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inzeraty
    ADD CONSTRAINT inzeraty_mesto_id_fkey FOREIGN KEY (mesto_id) REFERENCES mesta(id);


--
-- Name: oblubenost_inzeraty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY oblubenost
    ADD CONSTRAINT oblubenost_inzeraty_id_fkey FOREIGN KEY (inzeraty_id) REFERENCES inzeraty(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

